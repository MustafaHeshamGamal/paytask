package org.example.stepDefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P01_addToCart;
import org.testng.asserts.SoftAssert;

public class D01_addToCart {
    P01_addToCart addToCart = new P01_addToCart();
    SoftAssert soft = new SoftAssert();
    String productName;
    String productPrice;


    @Given("Scroll in the home page, till you find Hot deals sections")
    public void scroll_in_the_home_page_till_you_find_hot_deals_sections() {
        addToCart.viewAllBtn.click();
    }

    @When("Once the user is redirected to hot deals page, click on any item in the list")
    public void onceTheUserIsRedirectedToHotDealsPageClickOnAnyItemInTheList() throws InterruptedException {
    soft.assertTrue(addToCart.hotdealstitle.isDisplayed());
    soft.assertEquals(Hooks.driver.getCurrentUrl(),"https://momomarket.africa/Portal/category/1&300&Hot%20Deals");
    addToCart.randomproduct.click();
    soft.assertAll();

    }

    @And("Check the item description and price is valid and not empty")
    public void checkTheItemDescriptionAndPriceIsValidAndNotEmpty() {
        productName = addToCart.title.getText();
        productPrice = addToCart.price.getText();
        System.out.println(productName);
        System.out.println(productPrice);
        soft.assertEquals(addToCart.title.getText(),"EXERCISE BOOK A4 PICFARE CHAMPION,96 PAGES");
        soft.assertEquals(addToCart.price.getText(),"UGX 2,000.00");
        soft.assertAll();


    }

    @And("Click on add item to cart")
    public void clickOnAddItemToCart() {
        addToCart.addtocart.click();
        
    }

    @And("From the header, open the cart")
    public void fromTheHeaderOpenTheCart() {
        soft.assertTrue(addToCart.sucessMSG.isDisplayed());
        addToCart.cart.click();
        soft.assertAll();
    }

    @Then("Check the item placed is there with same price and same number of items")
    public void checkTheItemPlacedIsThereWithSamePriceAndSameNumberOfItems() {
        soft.assertEquals(addToCart.nameincart.getText(),productName);
        soft.assertEquals(addToCart.priceincart.getText(),productPrice);
        soft.assertAll();
    }
}
