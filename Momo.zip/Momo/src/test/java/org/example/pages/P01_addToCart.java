package org.example.pages;

import org.example.stepDefs.Hooks;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class P01_addToCart {
    public P01_addToCart(){
        PageFactory.initElements(Hooks.driver,this);
    }
    @FindBy(css = "div[class=\"content-container my-3X extra-pad\"] div:nth-child(6) span")
    public WebElement viewAllBtn;
    @FindBy(css = "div[class=\"my-5 flex flex-row justify-content-center flex-wrap ng-star-inserted\"] a:nth-of-type(7)")
    public  WebElement randomproduct;
    @FindBy(css = "section[class=\"information p-4 shadow-1\"] p[class=\"font-size-20\"]")
    public WebElement title;
    @FindBy(css = "section[class=\"information p-4 shadow-1\"] .price")
    public WebElement price;
    @FindBy(css = "button[class=\"p-element mr-1 width-50 main-btn p-button p-component ng-star-inserted\"]")
    public WebElement addtocart;
    @FindBy(css = "i[class=\"p-element pi pi-shopping-cart sign-in-logo p-overlay-badge\"]")
    public WebElement cart;
    @FindBy(className = "product_name")
    public WebElement nameincart;
    @FindBy(className = "tag-now")
    public WebElement priceincart;
    @FindBy(css = "div[class=\"font-size-22 bold-font\"]")
    public WebElement hotdealstitle;
    @FindBy(className = "p-toast-detail")
    public WebElement sucessMSG;
}
